## react-blogWebsite

Click here to check live:  https://react-blog-insights.netlify.app/

I built a blog website using HTML, CSS, JavaScript, and React. It allows users to view and interact with my blog posts. The website has a clean and modern design, and it is easy to navigate. I used HTML to structure the website, CSS to style it, and JavaScript to add interactivity. React made it easy to create reusable components for the website.

https://github.com/rohitraj232/react-blogWebsite/assets/57895889/ff7efd63-0908-4ee1-b603-aab8c569c446

# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh
